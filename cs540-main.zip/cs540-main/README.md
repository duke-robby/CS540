To set this project up a few pre-requisites are required. I highly reccomend using CentOS as the linux distibution.

# Apache Installation

Run the following command:

     yum install httpd

Use the systemd systemctl tool to start the Apache service:

     systemctl start httpd

Enable the service to start automatically on boot:

     systemctl enable httpd.service

Open up port 80 for web traffic:

     firewall-cmd --add-service=http --permanent

Reload the firewall:

     firewall-cmd --reload

Confirm successful installation by entering your server’s IP address in a browser to view the default Apache test page.

# PHP Installation
Run the following command:

     sudo yum install https://repo.ius.io/ius-release-el7.rpm

Install PHP and some popular PHP modules:

     yum install mod_php73 php73-cli php73-gd php73-ldap php73-mbstring php73-mysqlnd

Confirm your server is using PHP 7.3 by running the following command:

     php -v

You should see the following output:

    PHP 7.3.25 (cli) (built: Dec 1 2020 21:50:13) ( NTS )


Once you have installed PHP and Apache the project files can be moved to the web directory like so.

        cd ~/Downloads/rduke_cs540/
        mv ./* /var/www/html/

Ensure the database credentials are changed by modifying the system configuration in the file configuration.php under /private/system/
<?php ob_start ();
session_start ();
/**
 * -- File Metadata --
 * @author      Robert Duke <robby@dukemotorsports.net>
 * @date        01/28/22
 * @description System initializer and general organizer.
 */
error_reporting ( E_ALL );
# System security definitions.
define ( 'SYSTEM', true );

# Require system dependencies.
require_once ( './private/system/account.php' );
require_once ( './private/system/alto_router.php' );
require_once ( './private/system/configuration.php' );
require_once ( './private/system/functions.php' );
require_once ( './private/system/Twig/Autoloader.php' );

# Require logical handlers.
require_once ( './private/logic/account.php' );
require_once ( './private/logic/groups.php' );
require_once ( './private/logic/http_errors.php' );
require_once ( './private/logic/miscellaneous.php' );

# Create the Twig template engine instance.
Twig_Autoloader::register ();
$twig = new Twig_Environment( new Twig_Loader_Filesystem( './private/html' ) );

# Create MySQL handler if needed.
if ( $_MySQL[ 'enabled' ] ) {
    try {
        $dbh = new PDO( 'mysql:host=' . $_MySQL[ 'host' ] . ';dbname=' . $_MySQL[ 'database' ],
            $_MySQL[ 'user' ], $_MySQL[ 'password' ] );
    } catch ( PDOException $pdo_exception ) {
        CS540\Logic\HTTPErrors::server_error ();
    }
}

# If the account is authorized, then instantiate it.
$authorized_account = null;
if ( !empty( $_SESSION[ 'account_id' ] ) && is_numeric ( $_SESSION[ 'account_id' ] ) ) {
    $authorized_account = new CS540\System\Account( $_SESSION[ 'account_id' ] );
    $twig->addGlobal ( 'authorized_account', $authorized_account );
    $twig->addGlobal ( 'account_id', $authorized_account->get_id () );
    $twig->addGlobal ( 'account_full_name', $authorized_account->get_full_name () );
    $twig->addGlobal ( 'account_creation', $authorized_account->get_creation () );
    $twig->addGlobal ( 'account_email_address', $authorized_account->get_email_address () );
    # TODO
}

$twig->addGlobal ( '_POST', $_POST );
$twig->addGlobal ( '_GET', $_GET );

# Map out the routes.
$routing = new AltoRouter( [], '' );

$routing->map ( 'GET', '/errors/403', 'CS540\Logic\HTTPErrors::access_forbidden' );
$routing->map ( 'GET', '/errors/404', 'CS540\Logic\HTTPErrors::not_found' );
$routing->map ( 'GET', '/errors/500', 'CS540\Logic\HTTPErrors::server_error' );

# Account routes
if ( $authorized_account != null ) {
    $routing->map ( 'GET', '/account/home', 'CS540\Logic\Account::home' );
    $routing->map ( 'GET', '/account/manage', 'CS540\Logic\Account::manage' );
}

$routing->map ( 'GET', '/account/forgot_password', 'CS540\Logic\Account::forgot_password' );
$routing->map ( 'GET|POST', '/account/register', 'CS540\Logic\Account::register' );
$routing->map ( 'GET|POST', '/account/login', 'CS540\Logic\Account::login' );
$routing->map ( 'GET|POST', '/account/logout', 'CS540\Logic\Account::logout' );

if ( $authorized_account != null ) {
    # Group routes
    $routing->map ( 'GET|POST', '/groups/list', 'CS540\Logic\Groups::show_list' );
    $routing->map ( 'POST', '/groups/create_group', 'CS540\Logic\Groups::create_group' );
    $routing->map ( 'GET', '/groups/remove_group', 'CS540\Logic\Groups::remove_group' );
    $routing->map ( 'POST', '/groups/edit_title', 'CS540\Logic\Groups::edit_title' );

    # Node routes
    $routing->map ( 'GET', '/groups/nodes/remove_node', 'CS540\Logic\Groups::remove_node' );
    $routing->map ( 'POST', '/groups/nodes/add_node', 'CS540\Logic\Groups::add_node' );
} else {
    $routing->map ( 'GET|POST', '/[index|home|]', 'CS540\Logic\Account::login' );
}

$routing->map ( 'GET', '/search', 'CS540\Logic\Miscellaneous::search' );
$routing->map ( 'GET', '/search_import', 'CS540\Logic\Miscellaneous::import' );

# Route the request
$matched_route = $routing->match ();
if ( $matched_route && is_callable ( $matched_route[ 'target' ] ) ) {
    # Route was matched successfully.
    call_user_func_array ( $matched_route[ 'target' ], $matched_route[ 'params' ] );
} else {
    # No route was matched...
    CS540\Logic\HTTPErrors::not_found ();
}
/*
 Navicat MySQL Data Transfer

 Source Server         : Localhost - Development
 Source Server Type    : MariaDB
 Source Server Version : 100334
 Source Host           : localhost:3306
 Source Schema         : cs540

 Target Server Type    : MariaDB
 Target Server Version : 100334
 File Encoding         : 65001

 Date: 18/04/2022 19:15:37
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for account
-- ----------------------------
DROP TABLE IF EXISTS `account`;
CREATE TABLE `account` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `email_address` varchar(255) NOT NULL,
  `hashed_password` varchar(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `creation` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`,`email_address`) USING BTREE,
  KEY `id` (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for account_login_attempt
-- ----------------------------
DROP TABLE IF EXISTS `account_login_attempt`;
CREATE TABLE `account_login_attempt` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` smallint(5) unsigned NOT NULL,
  `remote_address` varchar(255) NOT NULL,
  `success` enum('true','false') NOT NULL,
  `creation` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  KEY `account_id` (`account_id`) USING BTREE,
  CONSTRAINT `account_login_attempt_ibfk_1` FOREIGN KEY (`account_id`) REFERENCES `account` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for group
-- ----------------------------
DROP TABLE IF EXISTS `group`;
CREATE TABLE `group` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `position` smallint(6) NOT NULL,
  `deletable` enum('true','false') NOT NULL DEFAULT 'true',
  `creation` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for group_node
-- ----------------------------
DROP TABLE IF EXISTS `group_node`;
CREATE TABLE `group_node` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `node` varchar(255) NOT NULL,
  `group` smallint(6) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `group` (`group`) USING BTREE,
  CONSTRAINT `group_node_ibfk_1` FOREIGN KEY (`group`) REFERENCES `group` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Table structure for media
-- ----------------------------
DROP TABLE IF EXISTS `media`;
CREATE TABLE `media` (
  `uuid` varchar(36) NOT NULL,
  `author` varchar(255) NOT NULL COMMENT 'UUID foreign key to the author table',
  `title` varchar(255) NOT NULL,
  `abstract` longtext CHARACTER SET utf8mb4 NOT NULL,
  `accessMode` enum('PHYSICAL','VIDEO','PDF','AUDIO') DEFAULT NULL,
  `systemCreation` datetime DEFAULT NULL,
  PRIMARY KEY (`uuid`) USING BTREE,
  KEY `Media Author` (`author`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for media_transaction
-- ----------------------------
DROP TABLE IF EXISTS `media_transaction`;
CREATE TABLE `media_transaction` (
  `uuid` varchar(36) DEFAULT NULL,
  `media` varchar(255) DEFAULT NULL,
  `user` varchar(36) DEFAULT NULL,
  `type` enum('OUT','IN') DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Table structure for mediaMeta
-- ----------------------------
DROP TABLE IF EXISTS `mediaMeta`;
CREATE TABLE `mediaMeta` (
  `uuid` varchar(36) DEFAULT NULL,
  `metaKey` varchar(255) DEFAULT NULL,
  `metaValue` longtext DEFAULT NULL,
  `systemCreation` datetime DEFAULT NULL,
  UNIQUE KEY `UUID Meta Key` (`uuid`,`metaKey`) USING BTREE,
  CONSTRAINT `Media Parent` FOREIGN KEY (`uuid`) REFERENCES `media` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Table structure for text_index
-- ----------------------------
DROP TABLE IF EXISTS `text_index`;
CREATE TABLE `text_index` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `text` longtext NOT NULL,
  `pdf` text NOT NULL,
  `date_added` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE,
  FULLTEXT KEY `text_index` (`text`,`pdf`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

SET FOREIGN_KEY_CHECKS = 1;

<?php
/**
 * -- File Metadata --
 *
 * @author      Robert Duke <robby@dukemotorsports.net>
 * @date        6/21/17
 * @description TODO
 */

function easy_pprint($var) {
    echo '<pre>';
    echo json_encode ($var, JSON_PRETTY_PRINT);
    echo '</pre>';
}

function hash_password($password) {
    return password_hash ($password, PASSWORD_DEFAULT);
}
<?php if ( !defined ( 'SYSTEM' ) ) exit( 'Script access forbidden.' );
/**
 * -- File Metadata --
 * @author      Robert Duke <robby@dukemotorsports.net>
 * @date        5/25/16
 * @description Configuration file for all system variables that need to be modifiable.
 */

# Database configuration
$_MySQL[ 'enabled' ]  = true;
$_MySQL[ 'host' ]     = 'localhost';
$_MySQL[ 'user' ]     = 'root';
$_MySQL[ 'password' ] = '';
$_MySQL[ 'database' ] = 'cs540';


<?php namespace CS540\System; if ( !defined ( 'SYSTEM' ) ) exit( 'Script access forbidden.' );
/**
 * Copyright (c) Duke Investments LLC 2022. All rights reserved.
 *
 * -- File Metadata --
 * @author      Robert Duke <robby@dukemotorsports.net>
 * @date        04/06/22
 * @description TODO
 */

class Media
{
    var $id,
        $author,
        $title,
        $abstract,
        $access_mode,
        $creation;


    /**
     * Account constructor.
     */
    public function __construct ( $identifier )
    {
        global $dbh;

        $media_query = null;
        
        # Identifier is an uuid.
        $media_query = $dbh->prepare ( 'select * from `media` where `uuid` = :identifier limit 1' );
        $media_query->execute ( [ ':identifier' => $identifier ] );

        if ( $media_query->rowCount () > 0 ) {
            # Select the first found media object and use it as the object.
            $media_data = $media_query->fetch ( \PDO::FETCH_ASSOC );

            $this->id = $media_data[ 'uuid' ];
            $this->author = $media_data[ 'author' ];
            $this->title = $media_data[ 'title' ];
            $this->abstract = $media_data[ 'abstract' ];
            $this->access_mode = $media_data[ 'accessMode' ];
            $this->creation = $media_data[ 'creation' ];
        } else {
            # No media found.
        }
    }

    /**
     * @return mixed
     */
    public function get_id ()
    {
        return $this->id;
    }

    public function onLoan() {
        global $dbh;

        $media_query = null;
        
        # Identifier is an uuid.
        $media_query = $dbh->prepare ( 'select `type` from `media_transaction` where `media` = :identifier order by `timestamp` desc limit 1' );
        $media_query->execute ( [ ':identifier' => $this->get_id() ] );

        if ( $media_query->rowCount () > 0 ) {
            # Select the first found media object and use it as the object.
            $media_data = $media_query->fetch ( \PDO::FETCH_ASSOC );
            # If last transaction on the book is a return then it is in the library, else it is lent out.
            return $media_data['type'] == 'IN';
        } else {
            return true;
        }
    }

    public function lastTransaction() {
        global $dbh;

        $media_query = null;
        
        # Identifier is an uuid.
        $media_query = $dbh->prepare ( 'select * from `media_transaction` where `media` = :identifier order by `timestamp` desc limit 1' );
        $media_query->execute ( [ ':identifier' => $this->get_id() ] );

        if ( $media_query->rowCount () > 0 ) {
            # Select the first found media object and use it as the object.
            $media_data = $media_query->fetch ( \PDO::FETCH_ASSOC );
            # If last transaction on the book is a return then it is in the library, else it is lent out.
            return $media_data;
        } else {
            return false;
        }
    }

    private function transaction($type, $account) {
        global $dbh;

        $media_query = null;
        $return = $dbh->lastInsertId;
        $media_query = $dbh->prepare( 'insert into `media_transaction` (`uuid`, `media`, `user`, `type`, `timestamp`) values (uuid(), :media, :user, :type, now())' );
        $media_query->execute([
            ':media' => $this->get_id(),
            ':user' => $account->get_id(),
            ':type' => $type
        ]);

        # check last insert id is not equal to the one prior to the query to ensure that the insertion ran.
        return $dbh->lastInsertId !== $return;
    }

    public function checkOut($account) {
        return $this->transaction('OUT', $account);
    }

    public function return($account) {
        return $this->transaction('IN', $account);
    }

    /**
     * @return mixed
     */
    public function get_creation ()
    {
        return $this->creation;
    }
}
<?php namespace CS540\System; if ( !defined ( 'SYSTEM' ) ) exit( 'Script access forbidden.' );
/**
 * Copyright (c) Duke Investments LLC 2022. All rights reserved.
 *
 * -- File Metadata --
 * @author      Robert Duke <robby@dukemotorsports.net>
 * @date        02/02/22
 * @description TODO
 */

class Account
{
    var $id,
        $full_name,
        $email_address,
        $hashed_password,
        $creation;


    /**
     * Account constructor.
     */
    public function __construct ( $identifier )
    {
        global $dbh;

        $account_query = null;
        if ( is_numeric ( $identifier ) ) {
            # Identifier is an id.
            $account_query = $dbh->prepare ( 'select * from `account` where `id` = :identifier' );
        } elseif ( filter_var ( $identifier, FILTER_VALIDATE_EMAIL ) ) {
            # Identifier is an email.
            $account_query = $dbh->prepare ( 'select * from `account` where `email_address` = :identifier' );
        } else {
            # What is it?
        }

        $account_query->execute ( [ ':identifier' => $identifier ] );
        if ( $account_query->rowCount () > 0 ) {
            # Select the first found account and use it as the object.
            $account_data = $account_query->fetch ( \PDO::FETCH_ASSOC );

            $this->id              = $account_data[ 'id' ];
            $this->full_name       = $account_data[ 'full_name' ];
            $this->email_address   = $account_data[ 'email_address' ];
            $this->hashed_password = $account_data[ 'hashed_password' ];
            $this->creation        = $account_data[ 'creation' ];

        } else {
            # No accounts found.
        }
    }

    /**
     * @return mixed
     */
    public function get_id ()
    {
        return $this->id;
    }

    /**
     * @return mixed
     */
    public function get_full_name ()
    {
        return $this->full_name;
    }

    /**
     * @param mixed $full_name
     */
    public function set_full_name ( $full_name )
    {
        $this->full_name = $full_name;
    }

    /**
     * @return mixed
     */
    public function get_email_address ()
    {
        return $this->email_address;
    }

    /**
     * @param mixed $email_address
     */
    public function set_email_address ( $email_address )
    {
        $this->email_address = $email_address;
    }

    /**
     * @return mixed
     */
    public function get_hashed_password ()
    {
        return $this->hashed_password;
    }

    /**
     * @param mixed $hashed_password
     */
    public function set_hashed_password ( $hashed_password )
    {
        $this->hashed_password = $hashed_password;
    }

    /**
     * @return mixed
     */
    public function get_creation ()
    {
        return $this->creation;
    }

    public function create_session ()
    {
        global $_SESSION, $dbh, $_SERVER;

        $log_attempted_login = $dbh->prepare ( 'insert into `account_login_attempt` (`account_id`, `remote_address`, `success`) values (:account_id, :remote_address, :success)' );

        $log_attempted_login->execute ( [
            ':account_id'     => $this->get_id (),
            ':remote_address' => $_SERVER[ 'REMOTE_ADDR' ],
            ':success'        => 'true',
        ] );


        $_SESSION[ 'account_id' ]    = $this->get_id ();
        $_SESSION[ 'email_address' ] = $this->get_email_address ();
        $_SESSION[ 'full_name' ]     = $this->get_full_name ();
    }

    public function destroy_session ()
    {
        session_destroy ();
    }
}
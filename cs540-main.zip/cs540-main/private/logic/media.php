<?php
/**
 * Copyright (c) Duke Investments LLC 2022. All rights reserved.
 *
 * -- File Metadata --
 * @author      Robert Duke <robby@dukemotorsports.net>
 * @date        01/31/22
 * @description General stuff like static pages that do not fall into another handler's scope.
 */

namespace CS540\Logic;

class Media
{
    public static function list()
    {
        global $twig, $dbh;
        $select_media = $dbh->prepare ( 'select * from `media` group by `title` order by `title`' );
        $select_media->execute ( );
        $twig->display ( '/media/list_media.twig', [ 'media' => $select_media->fetchAll ( \PDO::FETCH_ASSOC ) ] );
        exit;
    }
}
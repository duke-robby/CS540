<?php
/**
 * Copyright (c) Duke Investments LLC 2022. All rights reserved.
 *
 * -- File Metadata --
 * @author      Robert Duke <robby@dukemotorsports.net>
 * @date        01/31/22
 * @description Logical handler class for HTTP errors.
 */

namespace CS540\Logic;

class HTTPErrors
{
    public static function access_forbidden ()
    {
        global $twig;

        ob_clean ();
        http_response_code ( 403 );

        $twig->display ( '/errors/access_forbidden.twig' );
        exit;
    }

    public static function not_found ()
    {
        global $twig;

        ob_clean ();
        http_response_code ( 404 );

        $twig->display ( '/errors/not_found.twig' );
        exit;
    }

    public static function server_error ()
    {
        global $twig;

        ob_clean ();
        http_response_code ( 500 );

        $twig->display ( '/errors/server_error.twig' );
        exit;
    }
}
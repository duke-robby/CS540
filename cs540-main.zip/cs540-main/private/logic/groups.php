<?php
/**
 * Copyright (c) Duke Investments LLC 2022. All rights reserved.
 *
 * -- File Metadata --
 * @author      Robert Duke <robby@dukemotorsports.net>
 * @date        02/04/22
 * @description TODO
 */

namespace CS540\Logic;

class Groups
{
    public static function show_list ()
    {
        global $dbh, $twig;

        $select_groups = $dbh->query ( 'select * from `group`' );
        $groups        = $select_groups->fetchAll ( \PDO::FETCH_ASSOC );

        $select_group_nodes = $dbh->query ( 'select * from `group_node`' );
        $group_nodes        = $select_group_nodes->fetchAll ( \PDO::FETCH_ASSOC );

        $twig->display ( '/groups/list.twig', [ 'groups' => $groups, 'nodes' => $group_nodes ] );
    }

    public static function create_group ()
    {
        global $dbh;

        $insert_group = $dbh->prepare ( 'insert into `group` (`title`, `position`, `deletable`, `creation`) values (:title, :position, :deletable, now())' );
        $insert_group->execute ( [
            ':title'     => $_POST[ 'title' ],
            ':position'  => -1,
            ':deletable' => 'true',
        ] );

        header ( 'Location: /groups/list?created_group' );

        exit;
    }

    public static function remove_group ()
    {
        global $dbh;

        $insert_group = $dbh->prepare ( 'delete from `group` where `id` = :id and `deletable` = \'true\'' );
        $insert_group->execute ( [
            ':id' => $_GET[ 'id' ],
        ] );

        header ( 'Location: /groups/list?removed_group' );

        exit;
    }

    public static function add_node ()
    {
        global $dbh;

        $insert_group = $dbh->prepare ( 'insert into `group_node` (`node`, `group`) values (:node, :groups)' );
        $insert_group->execute ( [
            ':node'   => $_POST[ 'node' ],
            ':groups' => $_POST[ 'group' ],
        ] );

        header ( 'Location: /groups/list?created_node' );

        exit;
    }

    public static function remove_node ()
    {
        global $dbh;

        $insert_group = $dbh->prepare ( 'delete from `group_node` where `id` = :id' );
        $insert_group->execute ( [
            ':id' => $_GET[ 'id' ],
        ] );

        header ( 'Location: /groups/list?removed_node' );

        exit;
    }

    public static function edit_title ()
    {
        global $dbh;

        $update_title = $dbh->prepare ( 'update `group` set `title` = :title where `id` = :id' );
        $update_title->execute ( [ ':title' => $_POST[ 'value' ], ':id' => $_POST[ 'id' ] ] );

        echo $_POST[ 'value' ];


        exit;
    }
}
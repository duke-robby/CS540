<?php
/**
 * Copyright (c) Duke Investments LLC 2022. All rights reserved.
 *
 * -- File Metadata --
 * @author      Robert Duke <robby@dukemotorsports.net>
 * @date        01/31/22
 * @description General stuff like static pages that do not fall into another handler's scope.
 */

namespace CS540\Logic;

class Miscellaneous
{
    public static function import()
    {
        if($_GET['ROBBY'] != 'true') {
            HTTPErrors::not_found();
            exit;
        }
        
        require_once('/gps2dreamcollege.com/pdf-to-text-2017-05-31/import.php');
    }

    public static function about_us ()
    {
        global $twig;
        $twig->display ( '/about_us_new.twig' );
    }

    public static function courses ()
    {
        global $twig;
        $twig->display ( '/courses_new.twig' );
    }

    public static function students ()
    {
        global $twig;
        $twig->display ( '/students_new.twig' );
    }

    public static function observers ()
    {
        global $twig;
        $twig->display ( '/observers_new.twig' );
    }

    public static function landing ()
    {
        global $twig;
        $twig->display ( '/landing_new.twig' );
    }

    public static function publications ()
    {
        global $twig;
        $twig->display ( '/publications_new.twig' );
    }

    public static function search ()
    {
        global $twig, $dbh;

        $search = $dbh->prepare ( 'SELECT *, MATCH (`text`,`pdf`) AGAINST (:term IN BOOLEAN MODE) as `score` FROM `text_index` WHERE MATCH (`text`,`pdf`) AGAINST (:term IN BOOLEAN MODE) order by `score` desc' );
        $search->execute ( [
            ':term' => @$_GET[ 'term' ],
        ] );

        $results = $search->fetchAll ( \PDO::FETCH_ASSOC );
        $index = [];

        for ( $x = 0; $x < sizeof ( $results ); $x++ ) {
            if(!in_array($results[$x]['text'], $index)) {
                $index[] = $results[$x]['text'];
                $pos = strpos ( $results[$x]['text'], ' '. @$_GET[ 'term' ]. ' ' );
                $results[$x]['snippet'] = substr($results[$x]['text'], $pos - 50, 100 + strlen($_GET['term']));
                $results[$x]['snippet'] = str_replace( $_GET['term'], '<b>' . $_GET['term'] . '</b>',  $results[$x]['snippet']);
            } else {
            }
        }


        $twig->display ( '/search_new.twig', [ 'term' => @$_GET[ 'term' ], 'results' => $results ] );
    }
}
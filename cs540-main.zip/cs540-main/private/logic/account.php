<?php
/**
 * Copyright (c) Duke Investments LLC 2022. All rights reserved.
 *
 * -- File Metadata --
 * @author      Robert Duke <robby@dukemotorsports.net>
 * @date        02/02/22
 * @description TODO
 */

namespace CS540\Logic;

class Account
{

    public static function manage ()
    {
        global $twig, $dbh;
        $select_account = $dbh->prepare ( 'select * from `account` where `id` = :id' );
        $select_account->execute ( [ ':id' => $_SESSION[ 'account_id' ] ] );
        $twig->display ( '/account/manage.twig', [ 'account' => $select_account->fetch ( \PDO::FETCH_ASSOC ) ] );
    }

    public static function home ()
    {
        global $twig, $dbh;
        $select_account = $dbh->prepare ( 'select * from `account` where `id` = :id' );
        $select_account->execute ( [ ':id' => $_SESSION[ 'account_id' ] ] );
        $twig->display ( '/account/home.twig', [ 'account' => $select_account->fetch ( \PDO::FETCH_ASSOC ) ] );
    }

    public static function forgot_password ()
    {
        global $twig, $dbh;
        $twig->display ( '/account/forgot_password.twig' );
    }

    public static function login ()
    {
        global $twig, $dbh;

        if ( sizeof ( $_POST ) > 0 ) {
            $email    = $_POST[ 'email' ];
            $password = $_POST[ 'password' ];

            $select_account = $dbh->prepare ( 'select `id`, `hashed_password` from `account` where `email_address` = :email_address' );
            $select_account->execute ( [ ':email_address' => $email ] );

            if ( $select_account->rowCount () > 0 ) {
                $found_data          = $select_account->fetch ( \PDO::FETCH_ASSOC );
                $log_attempted_login = $dbh->prepare ( 'insert into `account_login_attempt` (`account_id`, `remote_address`, `success`) values (:account_id, :remote_address, :success)' );

                if ( password_verify ( $password, $found_data[ 'hashed_password' ] ) ) {
                    $_SESSION[ 'account_id' ] = $found_data[ 'id' ];
                    header ( 'Location: /account/home' );

                    $log_attempted_login->execute ( [
                        ':account_id'     => $found_data[ 'id' ],
                        ':remote_address' => $_SERVER[ 'REMOTE_ADDR' ],
                        ':success'        => 'true',
                    ] );

                    exit;
                } else {
                    $log_attempted_login->execute ( [
                        ':account_id'     => $found_data[ 'id' ],
                        ':remote_address' => $_SERVER[ 'REMOTE_ADDR' ],
                        ':success'        => 'false',
                    ] );

                    $twig->display ( '/account/login.twig', [ 'invalid_credentials' => true ] );
                }
            } else {
                $twig->display ( '/account/login.twig', [ 'invalid_credentials' => true ] );
            }
        } else {
            $twig->display ( '/account/login.twig' );
        }
    }

    public static function logout ()
    {
        global $twig, $dbh;

        session_destroy ();
        header ( 'Location: /' );
    }

    public static function register ()
    {
        global $twig, $dbh;

        $error_list = [];
        if ( sizeof ( $_POST ) > 0 ) {
            // Easy variable naming.
            $full_name    = $_POST[ 'full_name' ];
            $email        = $_POST[ 'email' ];
            $password     = $_POST[ 'password' ];
            $mailing_list = isset( $_POST[ 'mailing_list' ] );

            if ( !filter_var ( $email, FILTER_VALIDATE_EMAIL ) ) {
                // Invalid email.
                $error_list[] = 'Improper email.';
            }

            if ( empty( $full_name ) ) {
                // Invalid name.
                $error_list[] = 'Full name cannot be empty.';
            }

            if ( strlen ( $password ) <= 4 ) {
                // Invalid password.
                $error_list[] = 'Your password must be at least 4 characters long.';
            }

            $select_existing_email = $dbh->prepare ( 'select `id` from `account` where `email_address` = :email_address' );
            $select_existing_email->execute ( [ ':email_address' => $email ] );

            if ( $select_existing_email->rowCount () > 0 ) {
                $error_list[] = 'Email already in-use.';
            }


            if ( sizeof ( $error_list ) == 0 ) {
                // Create the account.
                $create_account = $dbh->prepare ( 'insert into `account` (`full_name`, `email_address`, `hashed_password`) values (:full_name, :email_address, :hashed_password)' );
                $create_account->execute ( [
                    ':full_name'       => $full_name,
                    ':email_address'   => $email,
                    ':hashed_password' => hash_password ( $password ),
                ] );

                $authorized_account = new \CS540\System\Account($email);
                $authorized_account->create_session ();


                header ( 'Location: /account/home' );
                exit;
            }
        }

        $twig->display ( '/account/register.twig', [ 'error_list' => $error_list ] );
    }
}